/******************************************************************************

Nombre del proyecto: Comprobacion de mayoria de edad
Autor: Aaron Casasola
Fecha: 24 de noviembre del 2025

*******************************************************************************/
#include <stdio.h>

int main()
{
    int edad;
    printf ("Ingresa tu edad:\n ");
    scanf ("%d", &edad);
    
    if (edad >=18)
        printf ("Bienvenido, Eres MAYOR de edad");
    
    if  (edad <18)
        printf ("Bienvenido, Eres MENOR de edad");   
}
   